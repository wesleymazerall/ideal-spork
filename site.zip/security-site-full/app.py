from flask import Flask, render_template, request, redirect, session, url_for
import json, os, time, hashlib

# ------------------ GPIO Setup ------------------
try:
    import RPi.GPIO as GPIO
    GPIO.setmode(GPIO.BCM)
    ARM_PIN = 18
    DISARM_PIN = 23  # Add second pin if needed

    # Configure pins as inputs with pull-up resistors
    GPIO.setup(ARM_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)
    GPIO.setup(DISARM_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)

    GPIO_AVAILABLE = True
except ImportError:
    GPIO_AVAILABLE = False

# ------------------ App Setup ------------------
app = Flask(__name__)
app.secret_key = "dev-secret-change"
DATA_DIR = "data"

# ------------------ JSON Helpers ------------------
def load_json(name, default):
    path = os.path.join(DATA_DIR, name)
    if not os.path.exists(path):
        with open(path, "w") as f:
            json.dump(default, f, indent=2)
    with open(path) as f:
        return json.load(f)

def save_json(name, data):
    with open(os.path.join(DATA_DIR, name), "w") as f:
        json.dump(data, f, indent=2)

# ------------------ Logging ------------------
def log(event):
    audit = load_json("audit.json", [])
    audit.append({
        "time": time.time(),
        "ip": request.remote_addr,
        "event": event
    })
    save_json("audit.json", audit)

# ------------------ IP Whitelist ------------------
def ip_allowed(ip):
    whitelist = load_json("ip_whitelist.json", [])
    return ip in whitelist

# ------------------ First Boot PIN ------------------
@app.route("/init_pin", methods=["GET", "POST"])
def init_pin():
    cfg = load_json("config.json", {"pin": "4321", "initialized": False})
    if request.method == "POST":
        cfg["pin"] = request.form["pin"]
        save_json("config.json", cfg)
        log("Initial PIN set")
        return redirect("/init_admin")
    return render_template("init_pin.html", title="Initial PIN")

# ------------------ Admin Setup ------------------
@app.route("/init_admin", methods=["GET", "POST"])
def init_admin():
    cfg = load_json("config.json", {"pin": "4321", "initialized": False})
    if request.method == "POST":
        users = {
            "admin": {
                "email": request.form["email"],
                "password": hashlib.sha256(request.form["password"].encode()).hexdigest(),
                "admin": True
            }
        }
        save_json("users.json", users)
        cfg["initialized"] = True
        save_json("config.json", cfg)
        log("Admin account created")
        return redirect("/pin")
    return render_template("init_admin.html", title="Admin Setup")

# ------------------ Daily PIN Layer ------------------
@app.route("/pin", methods=["GET", "POST"])
def pin():
    cfg = load_json("config.json", {"pin": "4321", "initialized": False})
    if request.method == "POST":
        if request.form["pin"] == cfg["pin"]:
            session["pin_ok"] = True
            return redirect("/login")
        log("Bad PIN attempt")
    return render_template("pin.html", title="Enter PIN")

# ------------------ Login ------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if not session.get("pin_ok"):
        return redirect("/pin")
    client_ip = request.remote_addr
    if request.method == "POST":
        users = load_json("users.json", {})
        for uid, u in users.items():
            if u["email"] == request.form["email"] and \
               u["password"] == hashlib.sha256(request.form["password"].encode()).hexdigest():
                session["uid"] = uid
                session["admin"] = u["admin"]
                log(f"Login OK: {uid}")
                if not ip_allowed(client_ip):
                    return redirect(url_for("ip_admin_auth"))
                return redirect("/home")
        log(f"Bad login attempt from {client_ip}")
    return render_template("login.html", title="Login")

# ------------------ IP Admin Auth ------------------
@app.route("/ip_admin_auth", methods=["GET", "POST"])
def ip_admin_auth():
    client_ip = request.remote_addr
    if request.method == "POST":
        users = load_json("users.json", {})
        for uid, u in users.items():
            if u["email"] == request.form["email"] and \
               u["password"] == hashlib.sha256(request.form["password"].encode()).hexdigest() and u["admin"]:
                session["pending_ip"] = client_ip
                log(f"Admin approved IP {client_ip}")
                return redirect("/ip_pin_confirm")
        log(f"Bad admin IP auth from {client_ip}")
    return render_template("ip_admin_auth.html", title="Admin Verification")

# ------------------ IP PIN Confirmation ------------------
@app.route("/ip_pin_confirm", methods=["GET", "POST"])
def ip_pin_confirm():
    client_ip = session.get("pending_ip")
    if not client_ip:
        return redirect("/pin")
    if request.method == "POST":
        cfg = load_json("config.json", {"pin": "4321", "initialized": True})
        if request.form["pin"] == cfg["pin"]:
            whitelist = load_json("ip_whitelist.json", [])
            if client_ip not in whitelist:
                whitelist.append(client_ip)
                save_json("ip_whitelist.json", whitelist)
                log(f"IP {client_ip} added to whitelist")
            return redirect("/home")
        log(f"Bad PIN for IP {client_ip}")
    return render_template("ip_pin_confirm.html", title="Confirm PIN for IP")

# ------------------ Home / Dashboard ------------------
@app.route("/home")
def home():
    # Require user to be logged in
    if "uid" not in session:
        return redirect("/pin")
    
    # Load user info
    users = load_json("users.json", {})
    uid = session["uid"]
    is_admin = session.get("admin", False)
    
    return render_template(
        "home.html",
        title="Home",
        uid=uid,
        is_admin=is_admin
    )

# ------------------ ARM/DISARM Control ------------------
# ------------------ ARM/DISARM Control ------------------
@app.route("/control/<action>", methods=["POST"])
def control(action):
    if "uid" not in session:
        return redirect("/pin")  # require login

    if not GPIO_AVAILABLE:
        log(f"{action.upper()} attempted but GPIO not available")
        return f"GPIO not available. {action.upper()} cannot be executed.", 503

    # ARM/DISARM pin check
    if action.lower() == "arm":
        # Pull-up: button pressed = LOW (0)
        if GPIO.input(ARM_PIN) != 0:
            log(f"ARM denied for {session['uid']}: ARM_PIN not pressed")
            return "ARM button not pressed. Action denied.", 403
    elif action.lower() == "disarm":
        if GPIO.input(DISARM_PIN) != 0:
            log(f"DISARM denied for {session['uid']}: DISARM_PIN not pressed")
            return "DISARM button not pressed. Action denied.", 403
    else:
        return "Invalid action.", 400

    # Action allowed, log it
    log(f"{action.upper()} executed by {session['uid']}")
    return redirect("/home")

# ------------------ Admin Logs ------------------
@app.route("/admin/logs")
def logs():
    if not session.get("admin"):
        return redirect("/home")
    logs_data = load_json("audit.json", [])
    return render_template("admin_logs.html", title="Audit Logs", logs=json.dumps(logs_data, indent=2))

# ------------------ Admin Dashboard ------------------
@app.route("/admin")
def admin_dashboard():
    if not session.get("admin"):
        return redirect("/home")  # only admins

    # Load all required data
    logs = load_json("audit.json", [])
    whitelist = load_json("ip_whitelist.json", [])
    users = load_json("users.json", {})

    # Render template with all three variables
    return render_template(
        "admin_dashboard.html",
        title="Admin Panel",
        logs=json.dumps(logs, indent=2),
        whitelist=whitelist,
        users=users
    )


# ------------------ Admin IP Whitelist ------------------
@app.route("/admin/ip_whitelist", methods=["GET", "POST"])
def admin_ip_whitelist():
    if not session.get("admin"):
        return redirect("/home")
    whitelist = load_json("ip_whitelist.json", [])
    if request.method == "POST":
        ip = request.form["ip"]
        if ip not in whitelist:
            whitelist.append(ip)
            save_json("ip_whitelist.json", whitelist)
            log(f"Admin added IP {ip} to whitelist")
    return render_template("ip_whitelist_admin.html", title="IP Whitelist", whitelist=whitelist)

# ------------------ Logout ------------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/pin")

@app.route("/admin/ip_whitelist", methods=["POST"])
def admin_ip_whitelist_post():
    if not session.get("admin"):
        return redirect("/home")
    whitelist = load_json("ip_whitelist.json", [])
    ip = request.form["ip"]
    if ip not in whitelist:
        whitelist.append(ip)
        save_json("ip_whitelist.json", whitelist)
        log(f"Admin added IP {ip} to whitelist")
    return redirect("/admin")

@app.route("/admin/add_user", methods=["POST"])
def admin_add_user():
    if not session.get("admin"):
        return redirect("/home")
    users = load_json("users.json", {})
    email = request.form["email"]
    password = hashlib.sha256(request.form["password"].encode()).hexdigest()
    is_admin = "admin" in request.form
    uid = email.split("@")[0] + str(int(time.time()))
    users[uid] = {"email": email, "password": password, "admin": is_admin}
    save_json("users.json", users)
    log(f"Admin added user {email}")
    return redirect("/admin")

@app.route("/admin/delete_user", methods=["POST"])
def admin_delete_user():
    if not session.get("admin"):
        return redirect("/home")
    users = load_json("users.json", {})
    uid = request.form["uid"]
    if uid in users:
        email = users[uid]["email"]
        del users[uid]
        save_json("users.json", users)
        log(f"Admin deleted user {email}")
    return redirect("/admin")




# ------------------ Run App ------------------
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")
